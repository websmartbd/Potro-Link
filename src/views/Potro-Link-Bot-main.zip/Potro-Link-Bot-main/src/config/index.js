const config = {
  BOT_TOKEN: '7642795354:AAGxCU6-5RC8pgNRCLMQWa49bWKM-PdNsWs', // Replace with your actual bot token
  PORT: process.env.PORT ||80, // You can set a default port here
};

module.exports = config; 